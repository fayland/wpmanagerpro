=== wpmanagerpro ===
Contributors: fayland
Tags: admin, administration, api, authentication, automatic, integration, seo, stats, tracking
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

wpmanagerpro plugin allows you to remotely manage your WordPress sites from one dashboard.

== Description ==

wpmanagerpro is a revolutionary plugin that helps users manage multiple WordPress blogs from one dashboard.

== Changelog ==

= 1.0.0 =
- working at Jun X, 2013

= 0.0.1 =
- new start at May 10, 2013

== Installation ==

1. Upload the plugin folder to your /wp-content/plugins/ folder
2. Go to the Plugins page and activate wpmanagerpro
3. Visit [wpmanagerpro](https://wpmanagerpro.com/), sign up and add your site
